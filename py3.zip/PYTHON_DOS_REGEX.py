import re
# <yes> <report> PYTHON_DOS_REGEX 6af533
re.compile(regex)
# <no> <report>
re.compile('[a-z]+')